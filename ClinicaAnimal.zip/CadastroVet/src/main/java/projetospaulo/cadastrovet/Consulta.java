package projetospaulo.cadastrovet;

import java.util.ArrayList;

public class Consulta extends javax.swing.JFrame {

    private ArrayList<Animal> listaAnimais;

    public Consulta(ArrayList<Animal> listaAnimais) {
        initComponents();
        this.listaAnimais = listaAnimais;
        exibirAnimais();
        this.setExtendedState(MAXIMIZED_BOTH);
    }

    private void exibirAnimais() {
        if(listaAnimais != null) {
            StringBuilder sb = new StringBuilder();
            for(Animal animal : listaAnimais) {
            sb.append("Código: ").append(animal.getCod()).append("\n");
            sb.append("Nome: ").append(animal.getNome()).append("\n");
            sb.append("Raça: ").append(animal.getRaca()).append("\n");
            sb.append("Data de Nascimento: ").append(animal.getDataNascimento()).append("\n");
            sb.append("Nome do Dono: ").append(animal.getNomeDono()).append("\n");
            sb.append("CPF do Dono: ").append(animal.getCpfDono()).append("\n");
            sb.append("Tipo de Animal: ").append(animal.getTipoAnimal()).append("\n");
            sb.append("\n");
            }
            jTextArea1.setText(sb.toString());
            
        }else{
            jTextArea1.setText("A lista de animais está vazia.");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuArquivo2 = new javax.swing.JMenu();
        menuCadastrar2 = new javax.swing.JMenuItem();
        menuConsultar2 = new javax.swing.JMenuItem();
        menuFechar2 = new javax.swing.JMenu();
        menuSair2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Animais Cadastrados");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        menuArquivo2.setText("Arquivo");

        menuCadastrar2.setText("Cadastrar");
        menuCadastrar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCadastrar2ActionPerformed(evt);
            }
        });
        menuArquivo2.add(menuCadastrar2);

        menuConsultar2.setText("Consultar");
        menuConsultar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuConsultar2ActionPerformed(evt);
            }
        });
        menuArquivo2.add(menuConsultar2);

        jMenuBar1.add(menuArquivo2);

        menuFechar2.setText("Fechar");

        menuSair2.setText("Sair");
        menuSair2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSair2ActionPerformed(evt);
            }
        });
        menuFechar2.add(menuSair2);

        jMenuBar1.add(menuFechar2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 785, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(0, 79, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 508, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(36, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void menuSair2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSair2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_menuSair2ActionPerformed

    private void menuCadastrar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadastrar2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_menuCadastrar2ActionPerformed

    private void menuConsultar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsultar2ActionPerformed
        this.setVisible(true);
    }//GEN-LAST:event_menuConsultar2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JMenu menuArquivo2;
    private javax.swing.JMenuItem menuCadastrar2;
    private javax.swing.JMenuItem menuConsultar2;
    private javax.swing.JMenu menuFechar2;
    private javax.swing.JMenuItem menuSair2;
    // End of variables declaration//GEN-END:variables

}
