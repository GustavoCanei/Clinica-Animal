package projetospaulo.cadastrovet;


public class Animal {
    
    private String cod;
    private String nome;
    private String raca;
    private String anoDeNascimento;
    private String nomeDono;
    private String cpfDono;
    private String tipoAnimal;

    public Animal(String cod, String nome, String raca, String anoDeNascimento, String nomeDono, String cpfDono, String tipoAnimal) {
        this.cod = cod;
        this.nome = nome;
        this.raca = raca;
        this.anoDeNascimento = anoDeNascimento;
        this.nomeDono = nomeDono;
        this.cpfDono = cpfDono;
        this.tipoAnimal = tipoAnimal;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getDataNascimento() {
        return anoDeNascimento;
    }

    public void setDataNascimento(String anoDeNascimento) {
        this.anoDeNascimento = anoDeNascimento;
    }

    public String getNomeDono() {
        return nomeDono;
    }

    public void setNomeDono(String nomeDono) {
        this.nomeDono = nomeDono;
    }

    public String getCpfDono() {
        return cpfDono;
    }

    public void setCpfDono(String cpfDono) {
        this.cpfDono = cpfDono;
    }

    public String getTipoAnimal() {
        return tipoAnimal;
    }

    public void setTipoAnimal(String tipoAnimal) {
        this.tipoAnimal = tipoAnimal;
    }
}
